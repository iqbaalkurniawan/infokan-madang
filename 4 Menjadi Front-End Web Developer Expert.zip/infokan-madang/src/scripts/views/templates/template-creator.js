import CONFIG from '../../globals/config';

const createRestaurantDetailTemplate = (restaurant) => `
<div class="restaurant-detail">
    <h1 class="restaurant-name">${restaurant.name}</h1>
    <picture>
        <source class="lazyload" srcset="${CONFIG.BASE_URL + CONFIG.IMAGE_SMALL + restaurant.pictureId}" type="image/webp" media="all and (max-width: 300px)" />
        <source class="lazyload" srcset="${CONFIG.BASE_URL + CONFIG.IMAGE_SMALL + restaurant.pictureId}" type="image/jpeg" media="all and (max-width: 300px)" />
        <source class="lazyload" srcset="${CONFIG.BASE_URL + CONFIG.IMAGE_MEDIUM + restaurant.pictureId}" type="image/webp" media="all and (min-width: 700px) and (max-width: 900px)" />
        <source class="lazyload" srcset="${CONFIG.BASE_URL + CONFIG.IMAGE_MEDIUM + restaurant.pictureId}" type="image/jpeg" media="all and (min-width: 700px) and (max-width: 900px)" />
        <source class="lazyload" srcset="${CONFIG.BASE_URL + CONFIG.IMAGE_LARGE + restaurant.pictureId}" type="image/webp" media="all and (min-width: 901px)" />
        <source class="lazyload" srcset="${CONFIG.BASE_URL + CONFIG.IMAGE_LARGE + restaurant.pictureId}" type="image/jpeg" media="all and (min-width: 901px)" />
        <img class="lazyload" data-src="${CONFIG.BASE_URL + CONFIG.IMAGE_MEDIUM + restaurant.pictureId}" alt="${restaurant.name}"/>
    </picture>

    <h4>Deskripsi</h4>
    <p>${restaurant.description}</p>

    <h4>Alamat</h4>
    <p>${restaurant.address}</p>

    <h4>Kota</h4>
    <p>${restaurant.city}</p>
    
    
    <h4>Menu Makanan</h4>
    <ul class="foods">
      ${restaurant.menus.foods
    .map(
      (food) => `
        <li>${food.name}</li>
      `,
    )
    .join('')}
    </ul>
   
    <h4>Menu Minuman</h4>
    <ul class="drinks">
        ${restaurant.menus.drinks
    .map(
      (drink) => `
            <li>${drink.name}</li>
        `,
    )
    .join('')}
    </ul>
    
    <h4>Ulasan Pelanggan</h4>

    <div class="customer-review">
        ${restaurant.customerReviews
    .map(
      (review) => `
            <div class="comment-section">
              <div class="comment">
                <div class="profile">
                  <p>👨</p>
                </div>
                <div class="comment-content">
                  <h3 class="comment-name">${review.name} <span class="comment-text">${review.review}</span> </h3>
                  <p class="comment-date">${review.date}</p>
                </div>
              </div>
            </div>
        `,
    )
    .join('')}
    </div>
    
</div>
`;

const createRestaurantItemTemplate = (restaurant) => `
  <a href="/#/detail/${restaurant.id}" class="card">
        <span>⭐️${restaurant.rating}</span>
        <img class="lazyload" data-src="${restaurant.pictureId ? CONFIG.BASE_URL + CONFIG.IMAGE_SMALL + restaurant.pictureId : 'https://picsum.photos/id/666/800/450?grayscale'}"  alt="${restaurant.name}"/>
        <div class="card-content">
        <h3 class="restaurant-name warung-item__header__poster">${restaurant.name}</h3>
        <b>${restaurant.city}</b>
        <p>${restaurant.description}</p>
        </div>
    </a>
`;

const createLikeButtonTemplate = () => `
  <button aria-label="like this restaurant" id="likeButton" class="like">
    <i class="fa fa-heart-o" aria-hidden="true"></i>
  </button>
`;

const createLikedButtonTemplate = () => `
  <button aria-label="unlike this restaurant" id="likeButton" class="like">
    <i class="fa fa-heart" aria-hidden="true"></i>
  </button>
`;

export {
  createRestaurantItemTemplate,
  createRestaurantDetailTemplate,
  createLikeButtonTemplate,
  createLikedButtonTemplate,
};
