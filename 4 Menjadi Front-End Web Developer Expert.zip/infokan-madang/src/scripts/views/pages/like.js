import FavoriteRestaurantIdb from '../../data/favorite-restaurant-idb';
import { createRestaurantItemTemplate } from '../templates/template-creator';

const Like = {
  async render() {
    return `
      <section class="restaurant">
        <h2 tabindex="0">Favorite Restaurant</h2>
        <div class="restaurant-menu" id="restaurant-menu"></div>
        <h2 class="restaurants-item__not__found"></h2>
      </section>
    `;
  },

  async afterRender() {
    const restaurants = await FavoriteRestaurantIdb.getListRestaurants();
    const restaurantContainer = document.querySelector('#restaurant-menu');
    const emptyContainer = document.querySelector('.restaurants-item__not__found');
    if (restaurants.length === 0) {
      emptyContainer.innerHTML = `
        Belum ada favorite restaurants
      `;
    }

    restaurants.forEach((restaurant) => {
      restaurantContainer.innerHTML += createRestaurantItemTemplate(restaurant);
    });
  },
};

export default Like;
