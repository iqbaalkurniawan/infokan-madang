import RestaurantDbSource from '../../data/restaurantdb-source';
import { createRestaurantItemTemplate } from '../templates/template-creator';

const exploreRestaurant = {
  async render() {
    return `
      <section class="restaurant">
        <h2 tabindex="0">Explore Restaurant</h2>
        <div class="restaurant-menu" id="restaurant-menu"></div>
      </section>
    `;
  },

  async afterRender() {
    const restaurants = await RestaurantDbSource.allRestaurant();
    const restaurantContainer = document.querySelector('#restaurant-menu');
    restaurants.forEach((restaurant) => {
      restaurantContainer.innerHTML += createRestaurantItemTemplate(restaurant);
    });
  },
};

export default exploreRestaurant;
