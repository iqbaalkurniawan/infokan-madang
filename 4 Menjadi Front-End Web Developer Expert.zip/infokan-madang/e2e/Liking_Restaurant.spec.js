/* eslint-disable no-undef */
const assert = require('assert');

Feature('Liking Restaurant');

Before(({ I }) => {
  I.amOnPage('/#/like');
});

Scenario('showing empty favorite restaurants', ({ I }) => {
  I.seeElement('#restaurant-menu');
  I.see('Belum ada favorite restaurants', '.restaurants-item__not__found');
});

Scenario('liking one restaurants', async ({ I }) => {
  I.seeElement('#restaurant-menu');
  I.see('Belum ada favorite restaurants', '.restaurants-item__not__found');

  I.amOnPage('/#/');
  I.seeElement('a.card');
  const firstCardRestaurant = locate('a.card').first();
  const firstCardRestaurantTitle = await I.grabTextFrom(firstCardRestaurant);
  I.click(firstCardRestaurant);

  I.seeElement('#likeButtonContainer');
  I.click('#likeButton');

  I.amOnPage('/#/like');
  I.seeElement('.card');
  const likedRestaurantTitle = await I.grabTextFrom('a.card');

  assert.strictEqual(firstCardRestaurantTitle, likedRestaurantTitle);
});

const { stack } = new Error();
console.log(stack);
