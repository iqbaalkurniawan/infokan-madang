const assert = require('assert');

Feature('Unliking Restaurant');

Before(({ I }) => {
  I.amOnPage('/#/like');
});

Scenario('Unliking one restaurant', async ({ I }) => {
  I.amOnPage('/#/');
  I.seeElement('a.card');
  const firstCardRestaurant = locate('a.card').first();
  const firstCardRestaurantTitle = await I.grabTextFrom(firstCardRestaurant);
  I.click(firstCardRestaurant);

  I.seeElement('#likeButtonContainer');
  I.click('#likeButton');

  I.amOnPage('/#/like');
  I.seeElement('.card');
  const likedRestaurantTitle = await I.grabTextFrom('a.card');

  assert.strictEqual(firstCardRestaurantTitle, likedRestaurantTitle);

  I.seeElement('a.card');
  const firstlikedCard = locate('a.card').first();
  I.click(firstlikedCard);

  I.seeElement('#likeButtonContainer');
  I.click('#likeButton');

  I.amOnPage('/#/like');
  I.seeElement('#restaurant-menu');
  I.see('Belum ada favorite restaurants', '.restaurants-item__not__found');
});

const { stack } = new Error();
console.log(stack);
